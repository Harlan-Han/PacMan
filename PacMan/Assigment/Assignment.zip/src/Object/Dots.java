package Object;

import java.awt.Rectangle;
import java.awt.Shape;
import java.util.ArrayList;
import java.util.List;



public class Dots {
	class Dot {
		private int x;
		private int y;
		private int width;
		private int height;
		private Rectangle dot;
		public Dot(int x, int y){
			this.x = x;
			this.y = y;
			width = 2;
			height = 2;
			dot = new Rectangle(x, y, width, height);
		}
	    public Shape getShape() {
	        return new Rectangle(dot);
	    }
	    public Rectangle getRect() {
	        return new Rectangle(x,y,width,height);
	    }
	    public boolean checkcollisions(Rectangle pm) {
	        return dot.intersects(pm);
	      }
	}
	
	private ArrayList<Dot> dots = new ArrayList<Dot>();
	private Dot dot;


	public Dots(int[] s) {
		int i =0 ;
        for(int y = 40; y!=520 ;y = y+20) {
        	for(int x = 0; x!=400 ; x = x+20) {
        		if(s[i] == 46) {//.
        			dot = new Dot(x+9,y+9);
        			dots.add(dot);
        		}
        		i++;
        	}
        }
	}	
	public List<Shape> getShapes() {
		List<Shape> dd = new ArrayList<Shape>();
		for (Dot d : dots) {
		    dd.add(d.getShape());
		}
		return dd;
    }
	public List<Rectangle> getRect() {
		List<Rectangle> dd = new ArrayList<Rectangle>();
		for (Dot d : dots) {
		    dd.add(d.getRect());
		}
		return dd;
    }
	public boolean checkCollisions(Rectangle pm) {
		boolean hit = false;
		Dot remove = null;
		for (Dot br : dots) {
		    if (br.checkcollisions(pm)) {
		        remove = br;
		        hit = true;
		    }
		}
		dots.remove(remove);
		return hit;
	}
	public int getDotsRemaining() {
		return dots.size();
	}
	
}
