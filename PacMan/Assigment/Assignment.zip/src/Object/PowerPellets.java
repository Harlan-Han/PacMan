package Object;


import java.awt.Rectangle;
import java.awt.Shape;
import java.util.ArrayList;
import java.util.List;


public class PowerPellets {
	class  PowerPellet{
		private int x;
		private int y;
		private int width;
		private int height;
		private Rectangle powerPellet;
		public PowerPellet(int x, int y){
			this.x = x;
			this.y = y;
			width = 10;
			height = 10;
			powerPellet = new Rectangle(x, y, width, height);
		}

	    public Shape getShape() {
	        return new Rectangle(powerPellet);
	    }
	    public Rectangle getRect() {
	        return new Rectangle(x,y,width,height);
	    }
	    
	    public boolean checkcollisions(Rectangle pm) {
	        return powerPellet.intersects(pm);
	    }
	}
	
	private ArrayList<PowerPellet> powerPellets = new ArrayList<PowerPellet>();
	private PowerPellet powerPellet;


	public PowerPellets(int[] s) {
		int i =0 ;
        for(int y = 40; y!=520 ;y = y+20) {
        	for(int x = 0; x!=400 ; x = x+20) {
        		if(s[i] == 42) {//*
        			powerPellet = new PowerPellet(x+3,y+3);
        			powerPellets.add(powerPellet);
        		}
        		i++;
        	}
        }
	}	
	public List<Shape> getShapes() {
		List<Shape> dd = new ArrayList<Shape>();
		for (PowerPellet d : powerPellets) {
		    dd.add(d.getShape());
		}
		return dd;
    }
	public List<Rectangle> getRect() {
		List<Rectangle> dd = new ArrayList<Rectangle>();
		for (PowerPellet d : powerPellets) {
		    dd.add(d.getRect());
		}
		return dd;
    }
	public boolean checkCollisions(Rectangle pm) {
	    boolean hit = false;
		PowerPellet remove = null;
		for (PowerPellet br : powerPellets) {
		    if (br.checkcollisions(pm)) {
		        remove = br;
		        hit = true;
		    }
	    }
		powerPellets.remove(remove);
		return hit;
	}
	public int getPowerRemaining() {
		return powerPellets.size();
	}
}
