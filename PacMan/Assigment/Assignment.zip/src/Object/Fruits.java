package Object;

import java.awt.Rectangle;
import java.awt.Shape;
import java.util.ArrayList;
import java.util.List;



public class Fruits {
	class Fruit {
		private int x;
		private int y;
		private int width;
		private int height;
		private Rectangle fruit;
		public Fruit(int x, int y){
			this.x = x;
			this.y = y;
			width = 6;
			height = 8;
			fruit = new Rectangle(x, y, width, height);
		}
	    public Shape getShape() {
	        return new Rectangle(fruit);
	    }
	    public Rectangle getRect() {
	        return new Rectangle(x,y,width,height);
	    }
	    public boolean checkcollisions(Rectangle pm) {
	        return fruit.intersects(pm);
	      }
	    
	}
	
	private ArrayList<Fruit> fruits = new ArrayList<Fruit>();
	private Fruit fruit;
	
	public Fruits(int[] s) {
		int i =0 ;
        for(int y = 40; y!=520 ;y = y+20) {
        	for(int x = 0; x!=400 ; x = x+20) {
        		if(s[i] == 70) {//F
        			fruit = new Fruit(x+5,y+5);
        			fruits.add(fruit);
        		}
        		i++;
        	}
        }
	}	
	public List<Shape> getShapes() {
		List<Shape> dd = new ArrayList<Shape>();
		for (Fruit d : fruits) {
		    dd.add(d.getShape());
		}
		return dd;
    }
	public List<Rectangle> getRect() {
		List<Rectangle> dd = new ArrayList<Rectangle>();
		for (Fruit d : fruits) {
		    dd.add(d.getRect());
		}
		return dd;
    }
	public boolean checkCollisions(Rectangle pm) {
		boolean hit = false;
		Fruit remove = null;
		for (Fruit br : fruits) {
		    if (br.checkcollisions(pm)) {
		        remove = br;
		        hit = true;
		    }
	    }
		fruits.remove(remove);
		return hit;
    }
}
