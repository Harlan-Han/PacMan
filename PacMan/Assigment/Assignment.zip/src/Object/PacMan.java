package Object;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import java.util.List;

import Outline.Game;
import keyboardControl.PlayerListener;

public class PacMan {
	private int x;
	private int y;
	private int width;
	private int height;
	private int speed;
	private Rectangle pacman;
	private int direction = 3 ;
	private List<Rectangle> walls;
	private PlayerListener listener;
	
	public PacMan(PlayerListener l,List<Rectangle> w) {
		listener= l;
		walls=w;
		x=20;
		y=60;
		width = 20;
		height = 20;
		speed = 5;
		pacman = new Rectangle(x,y,width,height);
	}
	
	public void drawSelf(Graphics2D g) {
		g.setColor(Color.YELLOW);
		if(getDirection() == 3) {//right
			g.fillArc(x, y, width, height, 45, 270);
		}
		else if(getDirection() == 2) {//left
			g.fillArc(x, y, width, height, 225, 270);
		}
		else if(getDirection() == 0) {//up
			g.fillArc(x, y, width, height, 135, 270);
		}
		else if(getDirection() == 1) {//down
			g.fillArc(x, y, width, height, 315, 270);
		}
	}
	private boolean checkcollisions(Rectangle pm,List<Rectangle> el){
    	boolean iscollisions = false;
    	for (Rectangle s : el) {
		    if(pm.intersects(s)) {
		    	iscollisions = true;
		    }
	    }
    	return iscollisions;
    }
	public int getDirection() {
		if (listener.left) {
	    	direction = 2 ;
	    } else if (listener.right) {
	    	direction = 3 ;
	    } else if (listener.up) {
	    	direction = 0 ;
	    } else if (listener.down) {
	    	direction = 1 ;
	    }
		return direction;
	}
	
	public void move() {
		Rectangle newBody = new Rectangle(this.x, this.y, width, height);
		if (Game.getScreenBounds().contains(newBody.getBounds())) {
			pacman = newBody;
			switch(getDirection()) {
			case 0:
				y = y - speed ;
				break;
			case 1:
				y = y + speed ;
				break;
			case 2:
				x = x - speed ;
				break;
			case 3: 
				x = x + speed ;
				break;
			}
			if(checkcollisions(getRect(),walls)) {
				switch(getDirection()) {
				case 0:
					y = y + speed ;
					break;
				case 1:
					y = y - speed ;
					break;
				case 2:
					x = x + speed ;
					break;
				case 3: 
					x = x - speed ;
					break;
				}
			}
		}
	}
	public Rectangle getRect() {
		return new Rectangle(x,y,width,height);
	}
	
	boolean die = false;
	public void died() {
		die = true;
	}
	public boolean isdied() {
		return die;
	}
	public void resetpacman() {
		x=20;
		y=60;
		die = false;
	}

}














