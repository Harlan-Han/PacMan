package Object;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Shape;
import java.util.ArrayList;
import java.util.List;

import Outline.Game;

public class Ghosts {
	public class Ghost{
		private int x;
		private int y;
		private int width;
		private int height;
		private int speed;
		private int direction = 0;
		private Rectangle ghost;
		private List<Rectangle> walls;
		public Ghost(int x, int y,List<Rectangle> w,int s){
			this.x = x;
			this.y = y;
			walls = w;
			width = 20;
			height = 20;
			speed = s;
			ghost = new Rectangle(x, y, width, height);
		}
		public void drawSelf(Graphics g) {
			g.fillOval(x+2, y, 16, 16);
			g.fillOval(x,y+15,5,5);
			g.fillOval(x+5,y+15,5,5);
			g.fillOval(x+10,y+15,5,5);
			g.fillOval(x+15,y+15,5,5);
		}
		private boolean checkcollisions(Rectangle pm,List<Rectangle> el){
	    	boolean iscollisions = false;
	    	for (Rectangle s : el) {
			    if(pm.intersects(s)) {
			    	iscollisions = true;
			    }
		    }
	    	return iscollisions;
	    }
		public boolean checkpmcollisions(Rectangle pm) {
	        return ghost.intersects(pm);
	      }
		private void move() {
			Rectangle newBody = new Rectangle(this.x, this.y, width, height);
			if (Game.getScreenBounds().contains(newBody.getBounds())) {
				ghost = newBody;
				switch(direction) {
				case 0:
					y = y - speed ;
					break;
				case 1:
					x = x - speed ;
					break;
				case 2:
					y = y + speed ;
					break;
				case 3: 
					x = x + speed ;
					break;
				}
				if(checkcollisions(getRect(),walls)) {
					switch(direction) {
					case 0:
						y = y + speed ;
						break;
					case 1:
						x = x + speed ;
						break;
					case 2:
						y = y - speed ;
						break;
					case 3: 
						x = x - speed ;
						break;
					}
					double r = Math.random();
				    if (r<0.25) {
				    	direction = 0;
				    } else if (r>=0.25&&r<0.5) {
				    	direction = 1;
				    } else if (r>=0.5&&r<0.75) {
				    	direction = 2;
				    } else if (r>=0.75) {
				    	direction = 3;
				    }
				}
			}
			
		}
        public Shape getShape() {
            return ghost;
        }
        public Rectangle getRect() {
            return new Rectangle(x,y,width,height);
        }
	}
	
	private ArrayList<Ghost> ghosts = new ArrayList<Ghost>();
	private Ghost ghost;
	public boolean isGreen = false;
	
	public Ghosts(int[] s,List<Rectangle> w,int speed) {
		int i =0 ;
        for(int y = 40; y!=520 ;y = y+20) {
        	for(int x = 0; x!=400 ; x = x+20) {
        		if(s[i] == 71) {//G
        			ghost = new Ghost(x,y,w,speed);
        			ghosts.add(ghost);
        		}
        		i++;
        	}
        }
	}
	public void moveAll() {
		for (Ghost g : ghosts) {
		    g.move();
		}
	}
	public int died(Rectangle pm) {
		Ghost remove = null;
		for (Ghost br : ghosts) {
		    if (br.checkpmcollisions(pm)) {
		        remove = br;
		    }
		}
		ghosts.remove(remove);
		return ghosts.size();
	}
	
	public List<Ghost> getGhost(){
		List<Ghost> gg = new ArrayList<Ghost>();
		for (Ghost g : ghosts) {
		    gg.add(g);
		}
		return gg;
	}
	public List<Rectangle> getRect() {
		List<Rectangle> gg = new ArrayList<Rectangle>();
		for (Ghost g : ghosts) {
		    gg.add(g.getRect());
		}
		return gg;
    }
	
}
