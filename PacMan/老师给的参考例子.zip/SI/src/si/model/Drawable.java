package si.model;

import java.awt.Shape;
import java.util.List;

public interface Drawable {
	public List<Shape> getShapes();
}
