package si.model;
/**
 * This interface is for representing all of the objects that can move in the game
 * this allows a shared use of the move method
 * @author Sean
 *
 */
public interface Movable {
  /**
   * This method should be called to make the object move on the screen
   */
	public void move();
}
