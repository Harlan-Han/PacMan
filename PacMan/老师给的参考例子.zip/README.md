# Space Invaders
This page gives an example of how you should structure your own readme page, indlucing listing the members of the project and your appraisal of how well you have done.
This project contains the Java code for a reimagining of the clasic arcade game Space Invaders.

The project was completed by;
- Sean Russell 06373313
- Sean Russell 06373313
- Sean Russell 06373313
- Sean Russell 06373313

The game has the following features
- Main Menu
- About screen
- Historical High Scores
- Play/pause functionality
- Life and score tracking
- Movable, shootable ship
- Destroyable bunkers
- Destroyable enemies

Difficulty is a bit high, and currently does not contain multiple levels but the initial version of the game is completed.

## Main Menu

![](images/menu.png)

## Gameplay

![](images/game.png)

## High Scores

![](images/score.png)

# Appraisal
For each of the following criteria, this is what the project achieves
### Design and Cohesion  (Excellent)
The project makes good use of Interfaces such as Drawable and Hittable to enable polymorphisim, enumerate types are used in appropriate places and there is a good overall package structure.
Classes all use good encapsulation and data hiding, and are designed to be cohesive.
### Input (Excellent)
User input is fully completed and all menus can be navigated as well as all in-game actions can be acomplished. These have been tested on Windows and Mac. 
### Display (Excellent)
All display on the screen are created using AWT and not loaded from images
### Menu (Excellent)
The menu displays all of the options in the program allowing the user to navigate the game
### Documentation (Pass)
There is documentation for some of the classes available in the doc folder, but it is not fully complete.


